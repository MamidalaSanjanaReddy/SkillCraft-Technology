# US Traffic Accidents — Pattern Analysis & Hotspot Visualization

Analyzes the [US Accidents dataset](https://www.kaggle.com/datasets/sobhanmoosavi/us-accidents)
(Sobhan Moosavi, Kaggle) to identify patterns in road conditions, weather, and time
of day, and visualizes accident hotspots on an interactive map.

Built for the **SkillCraft Technology** Data Science internship task.

## What this does

1. **Loads the data** — uses the Kaggle API to download the real dataset directly
   (requires a free Kaggle account + API token, see setup below). If that's not
   set up, or you're offline, it automatically falls back to a synthetic dataset
   with the same schema and realistic accident patterns (rush-hour peaks, worse
   severity in bad weather/at night, geographic clustering around metro areas),
   so the whole pipeline still runs.
2. **Cleans & engineers features**: hour of day, day of week, time-of-day bucket,
   rush-hour flag, simplified weather category, low-visibility flag, and a
   "near road feature" flag (junction / traffic signal / crossing).
3. **Analyzes patterns**:
   - Accidents by hour of day and day of week (plus a combined heatmap)
   - Severity broken down by weather condition and by visibility range
   - Severity near junctions, traffic signals, and crossings vs. away from them
   - Top accident-prone cities
   - A plain-text summary of the key findings
4. **Visualizes hotspots**:
   - A static density scatter plot colored by severity
   - A full **interactive Folium map** (`hotspot_map.html`) with a heatmap layer
     showing hotspot density plus a clustered marker layer you can click into for
     individual accident details (severity, weather, time)

## Project structure

```
us-accidents-analysis/
├── data/                          # dataset lands here (downloaded or synthetic)
├── outputs/                       # all generated plots, map, and summary report
├── src/
│   ├── data_loader.py             # Kaggle download / local load / synthetic fallback
│   ├── preprocessing.py           # cleaning + feature engineering
│   ├── analysis.py                # pattern aggregation functions
│   ├── visualize.py               # all static plots + interactive hotspot map
│   └── main.py                     # orchestrates the full pipeline (run this)
├── requirements.txt
└── README.md
```

## How to run in VS Code

### 1. Unzip and open the folder in VS Code

### 2. Create a virtual environment and install dependencies

```bash
python -m venv venv
```
Windows:
```bash
venv\Scripts\activate
```
macOS / Linux:
```bash
source venv/bin/activate
```
Then:
```bash
pip install -r requirements.txt
```

### 3. Set up Kaggle API access (optional, for the real dataset)

The real dataset is too large to embed and requires a Kaggle account to download:

1. Create a free account at [kaggle.com](https://www.kaggle.com)
2. Go to **Account → Create New API Token** — this downloads a `kaggle.json` file
3. Place it at:
   - Windows: `C:\Users\<you>\.kaggle\kaggle.json`
   - macOS/Linux: `~/.kaggle/kaggle.json`
4. (macOS/Linux only) restrict its permissions: `chmod 600 ~/.kaggle/kaggle.json`
5. Accept the dataset's terms once on its
   [Kaggle page](https://www.kaggle.com/datasets/sobhanmoosavi/us-accidents)
   (click "Download" once on the website — this registers your acceptance)

If you skip this step, the script automatically uses a realistic synthetic
dataset instead, so it will still run successfully.

### 4. Run the full pipeline

```bash
python src/main.py
```

By default this loads the first 50,000 rows (the real file has 7.7M+ rows and is
several GB — loading it all needs a lot of RAM). To change this:

```bash
python src/main.py --nrows 200000      # load more rows
python src/main.py --nrows None         # load the entire file (needs ~8GB+ RAM)
```

This will:
- Load (or download, or synthesize) the dataset
- Clean it and engineer time/weather/road features
- Print a summary of key findings to the terminal
- Save all plots + the summary report into `outputs/`
- Build `outputs/hotspot_map.html` — **open this file directly in any web
  browser** to explore the interactive accident hotspot map

### 5. View the interactive map

After running the script, open `outputs/hotspot_map.html` in your browser
(double-click it, or right-click → Open With → your browser). You'll see:
- A heat layer showing where accidents cluster most densely
- Toggleable marker clusters you can zoom into and click for accident details

## Notes on the real dataset

The real US Accidents dataset spans Feb 2016 – Mar 2023 and covers the
contiguous United States, compiled from multiple traffic APIs that aggregate
data from state DOTs, law enforcement, and traffic cameras/sensors. Useful
columns beyond what's used here include weather details (humidity, pressure),
POI annotations (nearby gas stations, bumps, stops), and detailed timezone
info — feel free to extend `USECOLS` in `data_loader.py` and add new
aggregations in `analysis.py` if you want to dig deeper.

## Customizing

- **Change the data sample size:** `--nrows` flag on `main.py`, or edit the
  default in `parse_args()`.
- **Add new patterns:** add a function to `analysis.py` following the existing
  `accidents_by_*` style (group, aggregate, return a tidy dataframe), then add
  a matching plot function in `visualize.py` and call both from `main.py`.
- **Map performance:** if `hotspot_map.html` is too large/slow to open, lower
  `--map-sample` (default 20,000 points for the heatmap, capped at 3,000 for
  individual clickable markers).
