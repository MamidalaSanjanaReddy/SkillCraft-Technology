"""
main.py
-------
End-to-end pipeline: load accident data -> clean & engineer features ->
analyze patterns (time of day, weather, road conditions) -> generate
all visualizations including the interactive hotspot map.

Run from the project root:
    python src/main.py

Optional: control how many rows are loaded (the real dataset is huge)
    python src/main.py --nrows 100000
    python src/main.py --nrows None      # load the full file (needs a lot of RAM)
"""

import os
import sys
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from data_loader import load_accidents_data
from preprocessing import full_feature_pipeline
from analysis import (
    accidents_by_hour, accidents_by_day_of_week, accidents_by_time_bucket,
    accidents_by_weather, severity_by_road_feature, top_accident_cities,
    weather_visibility_correlation, rush_hour_comparison, generate_summary_report
)
from visualize import (
    plot_accidents_by_hour, plot_accidents_by_day_of_week, plot_time_bucket_severity,
    plot_weather_breakdown, plot_visibility_severity, plot_road_feature_severity,
    plot_severity_distribution, plot_hour_heatmap_by_dow, plot_static_hotspot_density,
    build_interactive_hotspot_map, OUTPUT_DIR
)


def parse_args():
    parser = argparse.ArgumentParser(description="US Accidents pattern analysis pipeline")
    parser.add_argument("--nrows", type=str, default="50000",
                         help="Number of rows to load from the CSV (default 50000). "
                              "Pass 'None' to load the entire file.")
    parser.add_argument("--map-sample", type=int, default=20000,
                         help="Max number of points to plot on the interactive map (default 20000).")
    return parser.parse_args()


def main(nrows=50000, map_sample=20000):
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print("Step 1: Loading dataset...")
    df, source = load_accidents_data(nrows=nrows)
    print(f"Data source used: {source} | Rows loaded: {len(df):,}")

    print("\nStep 2: Cleaning data and engineering features...")
    df = full_feature_pipeline(df)
    print(f"Rows after cleaning: {len(df):,}")

    print("\nStep 3: Running pattern analysis...")
    by_hour = accidents_by_hour(df)
    by_dow = accidents_by_day_of_week(df)
    by_bucket = accidents_by_time_bucket(df)
    by_weather = accidents_by_weather(df)
    road_feature_df = severity_by_road_feature(df)
    top_cities = top_accident_cities(df)
    vis_df = weather_visibility_correlation(df)
    rush_df = rush_hour_comparison(df)

    summary = generate_summary_report(df)
    print("\n" + "=" * 60)
    print("SUMMARY OF KEY FINDINGS")
    print("=" * 60)
    print(summary)

    summary_path = os.path.join(OUTPUT_DIR, "summary_report.txt")
    with open(summary_path, "w") as f:
        f.write(summary)
        f.write("\n\nTop 10 cities by accident count:\n")
        f.write(top_cities.to_string(index=False))
    print(f"\nSaved text summary to {summary_path}")

    print("\nStep 4: Generating visualizations...")
    plot_accidents_by_hour(by_hour, os.path.join(OUTPUT_DIR, "accidents_by_hour.png"))
    plot_accidents_by_day_of_week(by_dow, os.path.join(OUTPUT_DIR, "accidents_by_day_of_week.png"))
    plot_time_bucket_severity(by_bucket, os.path.join(OUTPUT_DIR, "time_bucket_severity.png"))
    plot_weather_breakdown(by_weather, os.path.join(OUTPUT_DIR, "weather_breakdown.png"))
    plot_visibility_severity(vis_df, os.path.join(OUTPUT_DIR, "visibility_severity.png"))
    plot_road_feature_severity(road_feature_df, os.path.join(OUTPUT_DIR, "road_feature_severity.png"))
    plot_severity_distribution(df, os.path.join(OUTPUT_DIR, "severity_distribution.png"))
    plot_hour_heatmap_by_dow(df, os.path.join(OUTPUT_DIR, "hour_dow_heatmap.png"))
    plot_static_hotspot_density(df, os.path.join(OUTPUT_DIR, "hotspot_density_static.png"))

    print("\nStep 5: Building interactive hotspot map (this may take a moment)...")
    build_interactive_hotspot_map(
        df, save_path=os.path.join(OUTPUT_DIR, "hotspot_map.html"), sample_n=map_sample
    )

    print("\nTop 10 cities by accident count:")
    print(top_cities.to_string(index=False))

    print(f"\nAll done. Check the '{OUTPUT_DIR}' folder for all plots, the summary "
          f"report, and 'hotspot_map.html' (open it in any browser).")


if __name__ == "__main__":
    args = parse_args()
    nrows_val = None if args.nrows.lower() == "none" else int(args.nrows)
    main(nrows=nrows_val, map_sample=args.map_sample)
