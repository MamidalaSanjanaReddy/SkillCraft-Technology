"""
preprocessing.py
-----------------
Cleans the US Accidents data and engineers time-based and weather-based
features used throughout the analysis.
"""

import numpy as np
import pandas as pd


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Basic cleaning: parse dates, drop rows with missing coordinates, dedupe."""
    df = df.copy()
    df = df.drop_duplicates(subset=["ID"]) if "ID" in df.columns else df.drop_duplicates()

    for col in ("Start_Time", "End_Time"):
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce")

    df = df.dropna(subset=["Start_Lat", "Start_Lng", "Start_Time"])

    # Drop rows with nonsensical lat/lng (outside continental US bounding box,
    # generously defined to also cover AK/HI)
    df = df[(df["Start_Lat"].between(15, 72)) & (df["Start_Lng"].between(-170, -60))]

    return df


def engineer_time_features(df: pd.DataFrame) -> pd.DataFrame:
    """Adds hour, day-of-week, month, and a time-of-day bucket."""
    df = df.copy()
    df["Hour"] = df["Start_Time"].dt.hour
    df["DayOfWeek"] = df["Start_Time"].dt.day_name()
    df["Month"] = df["Start_Time"].dt.month_name()
    df["IsWeekend"] = df["Start_Time"].dt.dayofweek >= 5

    def bucket_time(h):
        if 5 <= h < 12:
            return "Morning (5am-12pm)"
        elif 12 <= h < 17:
            return "Afternoon (12pm-5pm)"
        elif 17 <= h < 21:
            return "Evening (5pm-9pm)"
        else:
            return "Night (9pm-5am)"

    df["TimeOfDayBucket"] = df["Hour"].apply(bucket_time)
    df["IsRushHour"] = df["Hour"].isin([7, 8, 9, 16, 17, 18])
    return df


def engineer_weather_features(df: pd.DataFrame) -> pd.DataFrame:
    """Buckets weather conditions and visibility into simpler categories."""
    df = df.copy()

    if "Weather_Condition" in df.columns:
        def simplify_weather(w):
            if pd.isna(w):
                return "Unknown"
            w = str(w).lower()
            if "clear" in w:
                return "Clear"
            if "cloud" in w or "overcast" in w:
                return "Cloudy"
            if "snow" in w or "sleet" in w or "ice" in w:
                return "Snow/Ice"
            if "rain" in w or "drizzle" in w or "shower" in w:
                return "Rain"
            if "fog" in w or "mist" in w or "haze" in w:
                return "Fog/Mist"
            if "thunder" in w or "storm" in w:
                return "Storm"
            return "Other"

        df["WeatherSimple"] = df["Weather_Condition"].apply(simplify_weather)
        df["IsBadWeather"] = ~df["WeatherSimple"].isin(["Clear", "Cloudy"])
    else:
        df["WeatherSimple"] = "Unknown"
        df["IsBadWeather"] = False

    if "Visibility(mi)" in df.columns:
        df["LowVisibility"] = df["Visibility(mi)"] < 3
    else:
        df["LowVisibility"] = False

    return df


def engineer_road_features(df: pd.DataFrame) -> pd.DataFrame:
    """Flags presence of junctions, signals, crossings as 'complex road feature' indicator."""
    df = df.copy()
    road_flags = [c for c in ("Junction", "Traffic_Signal", "Crossing") if c in df.columns]
    if road_flags:
        for c in road_flags:
            df[c] = df[c].astype(bool)
        df["NearRoadFeature"] = df[road_flags].any(axis=1)
    else:
        df["NearRoadFeature"] = False
    return df


def full_feature_pipeline(df: pd.DataFrame) -> pd.DataFrame:
    """Runs cleaning + all feature engineering steps in sequence."""
    df = clean_data(df)
    df = engineer_time_features(df)
    df = engineer_weather_features(df)
    df = engineer_road_features(df)
    return df
