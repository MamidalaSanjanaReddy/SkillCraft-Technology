"""
visualize.py
------------
All plotting functions: time-of-day / day-of-week patterns, weather
breakdowns, road-feature severity comparisons, and accident hotspot
maps (both a static density plot and an interactive Folium map).
"""

import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
import folium
from folium.plugins import HeatMap, MarkerCluster

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs")

sns.set_style("whitegrid")


def plot_accidents_by_hour(by_hour_df: pd.DataFrame, save_path=None):
    fig, ax1 = plt.subplots(figsize=(10, 5))
    ax2 = ax1.twinx()

    sns.barplot(data=by_hour_df, x="Hour", y="accident_count", ax=ax1, color="#4C72B0", alpha=0.8)
    ax2.plot(by_hour_df["Hour"], by_hour_df["avg_severity"], color="#C44E52",
             marker="o", linewidth=2, label="Avg Severity")

    ax1.set_xlabel("Hour of Day")
    ax1.set_ylabel("Accident Count", color="#4C72B0")
    ax2.set_ylabel("Average Severity", color="#C44E52")
    ax1.set_title("Accidents by Hour of Day (bars = count, line = avg severity)")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150)
        print(f"Saved: {save_path}")
    plt.close()


def plot_accidents_by_day_of_week(by_dow_df: pd.DataFrame, save_path=None):
    plt.figure(figsize=(9, 5))
    sns.barplot(data=by_dow_df, x="DayOfWeek", y="accident_count", color="#55A868")
    plt.title("Accidents by Day of Week")
    plt.xlabel("")
    plt.ylabel("Accident Count")
    plt.xticks(rotation=30)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150)
        print(f"Saved: {save_path}")
    plt.close()


def plot_time_bucket_severity(by_bucket_df: pd.DataFrame, save_path=None):
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))

    sns.barplot(data=by_bucket_df, x="TimeOfDayBucket", y="accident_count", ax=axes[0], color="#4C72B0")
    axes[0].set_title("Accident Count by Time of Day")
    axes[0].set_xlabel("")
    axes[0].tick_params(axis="x", rotation=20)

    sns.barplot(data=by_bucket_df, x="TimeOfDayBucket", y="avg_severity", ax=axes[1], color="#C44E52")
    axes[1].set_title("Average Severity by Time of Day")
    axes[1].set_xlabel("")
    axes[1].tick_params(axis="x", rotation=20)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150)
        print(f"Saved: {save_path}")
    plt.close()


def plot_weather_breakdown(by_weather_df: pd.DataFrame, save_path=None):
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))

    sns.barplot(data=by_weather_df, y="WeatherSimple", x="accident_count", ax=axes[0],
                order=by_weather_df.sort_values("accident_count", ascending=False)["WeatherSimple"],
                color="#4C72B0")
    axes[0].set_title("Accident Count by Weather Condition")
    axes[0].set_xlabel("Accident Count")
    axes[0].set_ylabel("")

    sns.barplot(data=by_weather_df, y="WeatherSimple", x="avg_severity", ax=axes[1],
                order=by_weather_df.sort_values("avg_severity", ascending=False)["WeatherSimple"],
                color="#C44E52")
    axes[1].set_title("Average Severity by Weather Condition")
    axes[1].set_xlabel("Average Severity")
    axes[1].set_ylabel("")

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150)
        print(f"Saved: {save_path}")
    plt.close()


def plot_visibility_severity(vis_df: pd.DataFrame, save_path=None):
    if vis_df.empty:
        return
    fig, ax1 = plt.subplots(figsize=(9, 5))
    ax2 = ax1.twinx()

    x = np.arange(len(vis_df))
    ax1.bar(x, vis_df["accident_count"], color="#4C72B0", alpha=0.8, label="Accident Count")
    ax2.plot(x, vis_df["avg_severity"], color="#C44E52", marker="o", linewidth=2, label="Avg Severity")

    ax1.set_xticks(x)
    ax1.set_xticklabels(vis_df["VisibilityBucket"])
    ax1.set_xlabel("Visibility Range")
    ax1.set_ylabel("Accident Count", color="#4C72B0")
    ax2.set_ylabel("Average Severity", color="#C44E52")
    ax1.set_title("Visibility vs. Accident Count & Severity")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150)
        print(f"Saved: {save_path}")
    plt.close()


def plot_road_feature_severity(road_df: pd.DataFrame, save_path=None):
    if road_df.empty:
        return
    melted = road_df.melt(
        id_vars="feature",
        value_vars=["avg_severity_with_feature", "avg_severity_without_feature"],
        var_name="presence", value_name="avg_severity"
    )
    melted["presence"] = melted["presence"].map({
        "avg_severity_with_feature": "Near feature",
        "avg_severity_without_feature": "No feature nearby"
    })

    plt.figure(figsize=(9, 5))
    sns.barplot(data=melted, x="feature", y="avg_severity", hue="presence")
    plt.title("Average Severity Near Road Features (Junctions, Signals, Crossings)")
    plt.xlabel("Road Feature")
    plt.ylabel("Average Severity")
    plt.legend(title="")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150)
        print(f"Saved: {save_path}")
    plt.close()


def plot_severity_distribution(df: pd.DataFrame, save_path=None):
    plt.figure(figsize=(7, 5))
    sns.countplot(data=df, x="Severity", color="#4C72B0")
    plt.title("Overall Accident Severity Distribution")
    plt.xlabel("Severity (1 = minor, 4 = severe)")
    plt.ylabel("Count")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150)
        print(f"Saved: {save_path}")
    plt.close()


def plot_hour_heatmap_by_dow(df: pd.DataFrame, save_path=None):
    """Heatmap of accident counts: day-of-week x hour-of-day."""
    order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    pivot = df.pivot_table(index="DayOfWeek", columns="Hour", values="Severity",
                            aggfunc="size", fill_value=0).reindex(order)

    plt.figure(figsize=(13, 5))
    sns.heatmap(pivot, cmap="YlOrRd", linewidths=0.5, linecolor="white")
    plt.title("Accident Frequency Heatmap: Day of Week vs. Hour of Day")
    plt.xlabel("Hour of Day")
    plt.ylabel("")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150)
        print(f"Saved: {save_path}")
    plt.close()


def plot_static_hotspot_density(df: pd.DataFrame, save_path=None, sample_n=20000):
    """A quick static scatter/density plot of accident locations, colored by severity.
    Useful as a fallback when an interactive map isn't needed (e.g. for embedding
    in a PDF/report)."""
    plot_df = df if len(df) <= sample_n else df.sample(sample_n, random_state=42)

    plt.figure(figsize=(11, 7))
    scatter = plt.scatter(
        plot_df["Start_Lng"], plot_df["Start_Lat"],
        c=plot_df["Severity"], cmap="YlOrRd", s=4, alpha=0.4
    )
    plt.colorbar(scatter, label="Severity")
    plt.title("Accident Locations (colored by severity)")
    plt.xlabel("Longitude")
    plt.ylabel("Latitude")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150)
        print(f"Saved: {save_path}")
    plt.close()


def build_interactive_hotspot_map(df: pd.DataFrame, save_path=None, sample_n=20000,
                                   center=None, zoom_start=4):
    """
    Builds an interactive Folium map with:
      - A heatmap layer showing accident density (the 'hotspots')
      - A clustered marker layer so individual accidents can be inspected
        (clicking a marker shows severity, weather, and time)
    Saves to an HTML file you can open directly in a browser.
    """
    plot_df = df if len(df) <= sample_n else df.sample(sample_n, random_state=42)

    if center is None:
        center = [plot_df["Start_Lat"].mean(), plot_df["Start_Lng"].mean()]

    m = folium.Map(location=center, zoom_start=zoom_start, tiles="cartodbpositron")

    # Heatmap layer (the "hotspot" view)
    heat_data = plot_df[["Start_Lat", "Start_Lng"]].values.tolist()
    HeatMap(heat_data, radius=8, blur=10, min_opacity=0.3).add_to(
        folium.FeatureGroup(name="Accident Density Heatmap").add_to(m)
    )

    # Clustered markers (the "inspect individual accidents" view) — capped
    # to a smaller sample so the HTML file doesn't get enormous.
    marker_sample = plot_df if len(plot_df) <= 3000 else plot_df.sample(3000, random_state=42)
    cluster = MarkerCluster(name="Individual Accidents").add_to(m)
    for _, row in marker_sample.iterrows():
        weather = row.get("WeatherSimple", "N/A")
        sev = row.get("Severity", "N/A")
        time_str = row["Start_Time"].strftime("%Y-%m-%d %H:%M") if pd.notna(row.get("Start_Time")) else "N/A"
        city = row.get("City", "")
        popup_html = (
            f"<b>Severity:</b> {sev}<br>"
            f"<b>Weather:</b> {weather}<br>"
            f"<b>Time:</b> {time_str}<br>"
            f"<b>City:</b> {city}"
        )
        color = {1: "green", 2: "orange", 3: "red", 4: "darkred"}.get(int(sev) if pd.notna(sev) else 1, "gray")
        folium.CircleMarker(
            location=[row["Start_Lat"], row["Start_Lng"]],
            radius=4,
            color=color,
            fill=True,
            fill_opacity=0.7,
            popup=folium.Popup(popup_html, max_width=250)
        ).add_to(cluster)

    folium.LayerControl().add_to(m)

    if save_path:
        m.save(save_path)
        print(f"Saved interactive hotspot map: {save_path}")
    return m
