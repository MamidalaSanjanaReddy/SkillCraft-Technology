"""
analysis.py
-----------
Pattern-detection functions: aggregates accident counts and severity
by time of day, weather condition, and road feature presence.
"""

import pandas as pd


def accidents_by_hour(df: pd.DataFrame) -> pd.DataFrame:
    return (
        df.groupby("Hour")
        .agg(accident_count=("Severity", "size"), avg_severity=("Severity", "mean"))
        .reset_index()
        .sort_values("Hour")
    )


def accidents_by_day_of_week(df: pd.DataFrame) -> pd.DataFrame:
    order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    result = (
        df.groupby("DayOfWeek")
        .agg(accident_count=("Severity", "size"), avg_severity=("Severity", "mean"))
        .reindex(order)
        .reset_index()
    )
    return result


def accidents_by_time_bucket(df: pd.DataFrame) -> pd.DataFrame:
    order = ["Morning (5am-12pm)", "Afternoon (12pm-5pm)", "Evening (5pm-9pm)", "Night (9pm-5am)"]
    result = (
        df.groupby("TimeOfDayBucket")
        .agg(accident_count=("Severity", "size"), avg_severity=("Severity", "mean"))
        .reindex(order)
        .reset_index()
    )
    return result


def accidents_by_weather(df: pd.DataFrame) -> pd.DataFrame:
    return (
        df.groupby("WeatherSimple")
        .agg(accident_count=("Severity", "size"), avg_severity=("Severity", "mean"))
        .reset_index()
        .sort_values("accident_count", ascending=False)
    )


def severity_by_road_feature(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for col in ("Junction", "Traffic_Signal", "Crossing", "NearRoadFeature"):
        if col in df.columns:
            present = df[df[col] == True]
            absent = df[df[col] == False]
            rows.append({
                "feature": col,
                "accidents_with_feature": len(present),
                "avg_severity_with_feature": present["Severity"].mean() if len(present) else float("nan"),
                "accidents_without_feature": len(absent),
                "avg_severity_without_feature": absent["Severity"].mean() if len(absent) else float("nan"),
            })
    return pd.DataFrame(rows)


def top_accident_cities(df: pd.DataFrame, n: int = 10) -> pd.DataFrame:
    if "City" not in df.columns:
        return pd.DataFrame()
    return (
        df.groupby(["City", "State"])
        .agg(accident_count=("Severity", "size"), avg_severity=("Severity", "mean"))
        .reset_index()
        .sort_values("accident_count", ascending=False)
        .head(n)
    )


def weather_visibility_correlation(df: pd.DataFrame) -> pd.DataFrame:
    """Average severity broken down by visibility bucket, to show the
    visibility -> severity relationship clearly."""
    if "Visibility(mi)" not in df.columns:
        return pd.DataFrame()
    df = df.copy()
    bins = [-0.01, 1, 3, 5, 10, 100]
    labels = ["<1 mi", "1-3 mi", "3-5 mi", "5-10 mi", ">10 mi"]
    df["VisibilityBucket"] = pd.cut(df["Visibility(mi)"], bins=bins, labels=labels)
    return (
        df.groupby("VisibilityBucket")
        .agg(accident_count=("Severity", "size"), avg_severity=("Severity", "mean"))
        .reset_index()
    )


def rush_hour_comparison(df: pd.DataFrame) -> pd.DataFrame:
    return (
        df.groupby("IsRushHour")
        .agg(accident_count=("Severity", "size"), avg_severity=("Severity", "mean"))
        .reset_index()
        .rename(index={0: "Off-peak", 1: "Rush Hour"})
    )


def generate_summary_report(df: pd.DataFrame) -> str:
    """Builds a short plain-text summary of the key findings, useful for
    printing to the console or saving alongside the plots."""
    lines = []
    lines.append(f"Total accidents analyzed: {len(df):,}")
    lines.append(f"Date range: {df['Start_Time'].min()} to {df['Start_Time'].max()}")
    lines.append(f"Average severity (1-4 scale): {df['Severity'].mean():.2f}")

    by_hour = accidents_by_hour(df)
    peak_hour = by_hour.loc[by_hour["accident_count"].idxmax()]
    lines.append(f"Peak accident hour: {int(peak_hour['Hour'])}:00 "
                 f"({int(peak_hour['accident_count']):,} accidents)")

    by_weather = accidents_by_weather(df)
    if not by_weather.empty:
        top_weather = by_weather.iloc[0]
        lines.append(f"Most common weather condition during accidents: "
                     f"{top_weather['WeatherSimple']} ({int(top_weather['accident_count']):,} accidents)")
        bad_weather_severity = df[df["IsBadWeather"]]["Severity"].mean()
        clear_weather_severity = df[~df["IsBadWeather"]]["Severity"].mean()
        lines.append(f"Avg severity in bad weather: {bad_weather_severity:.2f} "
                     f"vs. clear/cloudy: {clear_weather_severity:.2f}")

    if "Sunrise_Sunset" in df.columns:
        night_sev = df[df["Sunrise_Sunset"] == "Night"]["Severity"].mean()
        day_sev = df[df["Sunrise_Sunset"] == "Day"]["Severity"].mean()
        lines.append(f"Avg severity at night: {night_sev:.2f} vs. day: {day_sev:.2f}")

    rush = rush_hour_comparison(df)
    if not rush.empty:
        lines.append("Rush hour vs off-peak accident counts:")
        for _, row in rush.iterrows():
            label = "Rush Hour" if row["IsRushHour"] else "Off-peak"
            lines.append(f"  {label}: {int(row['accident_count']):,} accidents, "
                         f"avg severity {row['avg_severity']:.2f}")

    return "\n".join(lines)
