"""
data_loader.py
---------------
Loads the Sobhan Moosavi "US Accidents" dataset from Kaggle:
https://www.kaggle.com/datasets/sobhanmoosavi/us-accidents

Behavior:
1. If a local CSV already exists in data/, use it.
2. Otherwise, try to download it via the official Kaggle API
   (requires a Kaggle account + API token — see README).
3. If neither works (no token, no internet, sandboxed environment),
   fall back to a realistic synthetic dataset with the same schema
   and similar statistical patterns (rush-hour peaks, more accidents
   in bad weather/poor visibility, severity tied to road conditions),
   so the rest of the pipeline always runs end-to-end.

The real dataset has 7.7M+ rows and is several GB, so by default we
also support loading only a random sample (`nrows` / `sample_frac`)
to keep things fast and laptop-friendly.
"""

import os
import subprocess
import numpy as np
import pandas as pd

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
KAGGLE_DATASET = "sobhanmoosavi/us-accidents"

# Columns we actually need for this analysis (the real file has 40+ columns;
# we only load these to keep memory usage manageable).
USECOLS = [
    "ID", "Severity", "Start_Time", "End_Time", "Start_Lat", "Start_Lng",
    "City", "State", "Temperature(F)", "Visibility(mi)", "Wind_Speed(mph)",
    "Precipitation(in)", "Weather_Condition", "Road_Surface_Condition" if False else None,
    "Sunrise_Sunset", "Junction", "Traffic_Signal", "Crossing",
]
USECOLS = [c for c in USECOLS if c is not None]


def _try_kaggle_download(dest_dir: str) -> str | None:
    """Attempt to download via the Kaggle CLI/API. Returns path to extracted CSV or None."""
    os.makedirs(dest_dir, exist_ok=True)
    try:
        print(f"Attempting Kaggle download of '{KAGGLE_DATASET}' ...")
        result = subprocess.run(
            ["kaggle", "datasets", "download", "-d", KAGGLE_DATASET, "-p", dest_dir, "--unzip"],
            capture_output=True, text=True, timeout=600
        )
        if result.returncode != 0:
            print(f"Kaggle CLI failed:\n{result.stderr.strip()}")
            return None
        # The dataset's CSV filename has varied across versions; search for it.
        for fname in os.listdir(dest_dir):
            if fname.lower().startswith("us_accidents") and fname.lower().endswith(".csv"):
                full_path = os.path.join(dest_dir, fname)
                print(f"Downloaded: {full_path}")
                return full_path
        print("Kaggle download succeeded but no matching CSV was found in the archive.")
        return None
    except FileNotFoundError:
        print("Kaggle CLI not installed (pip install kaggle) — skipping download attempt.")
        return None
    except Exception as e:
        print(f"Kaggle download failed ({e}). Will fall back to synthetic data.")
        return None


def _generate_synthetic_dataset(n_samples: int = 50000, random_state: int = 42) -> pd.DataFrame:
    """
    Generates a realistic synthetic accident dataset mirroring real-world
    patterns documented in US traffic safety research:
      - Accident volume peaks during morning (7-9am) and evening (4-6pm) rush hours
      - More accidents in poor weather (rain, snow, fog) and low visibility
      - Higher severity associated with night-time, poor visibility, and junctions
      - Geographic clustering around a handful of major metro areas (hotspots)
    Used only as an offline fallback so the project runs end-to-end without
    a Kaggle account or internet access.
    """
    rng = np.random.RandomState(random_state)

    # A handful of major US metro centers to create realistic geographic clustering
    metros = {
        "Los Angeles": (34.05, -118.24, "CA"),
        "Houston": (29.76, -95.37, "TX"),
        "New York": (40.71, -74.01, "NY"),
        "Chicago": (41.88, -87.63, "IL"),
        "Miami": (25.76, -80.19, "FL"),
        "Atlanta": (33.75, -84.39, "GA"),
        "Dallas": (32.78, -96.80, "TX"),
        "Phoenix": (33.45, -112.07, "AZ"),
        "Seattle": (47.61, -122.33, "WA"),
        "Charlotte": (35.23, -80.84, "NC"),
    }
    metro_names = list(metros.keys())
    # Weight some cities as bigger "hotspots" (matches real dataset where CA/TX/FL dominate)
    metro_weights = [0.22, 0.14, 0.10, 0.10, 0.09, 0.08, 0.08, 0.07, 0.06, 0.06]

    city_choice = rng.choice(metro_names, n_samples, p=metro_weights)

    # Hour of day with bimodal rush-hour peaks
    hour_weights = np.array([
        1, 0.6, 0.4, 0.4, 0.6, 1.5, 3.5, 6, 6.5, 4, 3, 3,
        3.2, 3, 3.2, 4, 6, 6.8, 5, 3.5, 2.5, 2, 1.5, 1.2
    ])
    hour_probs = hour_weights / hour_weights.sum()
    hours = rng.choice(np.arange(24), n_samples, p=hour_probs)

    days_offset = rng.randint(0, 365 * 3, n_samples)  # spread over ~3 years
    base_date = pd.Timestamp("2021-01-01")
    minutes = rng.randint(0, 60, n_samples)
    start_times = [base_date + pd.Timedelta(days=int(d), hours=int(h), minutes=int(m))
                   for d, h, m in zip(days_offset, hours, minutes)]
    durations_min = rng.exponential(35, n_samples).astype(int) + 5
    end_times = [st + pd.Timedelta(minutes=int(d)) for st, d in zip(start_times, durations_min)]

    weather_conditions = ["Clear", "Cloudy", "Rain", "Light Rain", "Heavy Rain",
                           "Snow", "Fog", "Thunderstorm", "Overcast"]
    # Weather is correlated loosely with season; for simplicity we sample with
    # realistic overall base rates rather than full seasonal modeling.
    weather_probs = [0.40, 0.20, 0.12, 0.08, 0.04, 0.04, 0.05, 0.03, 0.04]
    weather = rng.choice(weather_conditions, n_samples, p=weather_probs)

    is_bad_weather = np.isin(weather, ["Rain", "Light Rain", "Heavy Rain", "Snow", "Fog", "Thunderstorm"])

    temperature = rng.normal(62, 18, n_samples)
    visibility = np.where(
        is_bad_weather,
        np.clip(rng.normal(3.5, 2.5, n_samples), 0.1, 10),
        np.clip(rng.normal(9.5, 1.0, n_samples), 0.1, 10)
    )
    wind_speed = np.clip(rng.normal(8, 5, n_samples), 0, 45)
    precipitation = np.where(is_bad_weather, np.clip(rng.exponential(0.3, n_samples), 0, 3), 0.0)

    is_night = np.array([h >= 19 or h <= 5 for h in hours])
    sunrise_sunset = np.where(is_night, "Night", "Day")

    junction = rng.choice([True, False], n_samples, p=[0.18, 0.82])
    traffic_signal = rng.choice([True, False], n_samples, p=[0.22, 0.78])
    crossing = rng.choice([True, False], n_samples, p=[0.12, 0.88])

    # Severity (1=minor - 4=severe) driven by realistic risk factors
    severity_score = (
        1.0
        + 0.7 * is_bad_weather
        + 0.6 * is_night
        + 0.4 * (visibility < 2)
        + 0.3 * junction
        + rng.normal(0, 0.6, n_samples)
    )
    severity = np.clip(np.round(severity_score), 1, 4).astype(int)

    lat_jitter = rng.normal(0, 0.35, n_samples)
    lng_jitter = rng.normal(0, 0.35, n_samples)
    # Add finer clustering: most accidents near downtown core, fewer in outskirts
    cluster_tightness = rng.exponential(0.15, n_samples)
    lat_jitter = np.sign(lat_jitter) * np.minimum(np.abs(lat_jitter), cluster_tightness * 3)
    lng_jitter = np.sign(lng_jitter) * np.minimum(np.abs(lng_jitter), cluster_tightness * 3)

    start_lat, start_lng, state = [], [], []
    for city in city_choice:
        lat0, lng0, st = metros[city]
        start_lat.append(lat0)
        start_lng.append(lng0)
        state.append(st)
    start_lat = np.array(start_lat) + lat_jitter
    start_lng = np.array(start_lng) + lng_jitter

    df = pd.DataFrame({
        "ID": [f"SYN-{i}" for i in range(n_samples)],
        "Severity": severity,
        "Start_Time": start_times,
        "End_Time": end_times,
        "Start_Lat": start_lat,
        "Start_Lng": start_lng,
        "City": city_choice,
        "State": state,
        "Temperature(F)": temperature.round(1),
        "Visibility(mi)": visibility.round(1),
        "Wind_Speed(mph)": wind_speed.round(1),
        "Precipitation(in)": precipitation.round(2),
        "Weather_Condition": weather,
        "Sunrise_Sunset": sunrise_sunset,
        "Junction": junction,
        "Traffic_Signal": traffic_signal,
        "Crossing": crossing,
    })
    return df


def load_accidents_data(sample_frac: float | None = None, nrows: int | None = 50000,
                         random_state: int = 42) -> tuple[pd.DataFrame, str]:
    """
    Loads the US Accidents dataset.

    Parameters
    ----------
    sample_frac : float, optional
        If set (0 < sample_frac <= 1), randomly samples this fraction of rows
        AFTER loading. Useful for the full multi-GB real dataset.
    nrows : int, optional
        If set, reads only the first `nrows` rows from disk (fast, avoids
        loading multi-GB files into memory). Ignored for the synthetic
        fallback, which is generated directly at the requested size.
        Set to None to load the entire file.
    random_state : int
        Seed for reproducible sampling / synthetic generation.

    Returns
    -------
    df : pd.DataFrame
    source : str — "local", "downloaded", or "synthetic"
    """
    os.makedirs(DATA_DIR, exist_ok=True)

    local_csv = None
    if os.path.isdir(DATA_DIR):
        for fname in os.listdir(DATA_DIR):
            if fname.lower().startswith("us_accidents") and fname.lower().endswith(".csv"):
                local_csv = os.path.join(DATA_DIR, fname)
                break

    if local_csv is None:
        local_csv = _try_kaggle_download(DATA_DIR)
        source = "downloaded" if local_csv else None
    else:
        source = "local"

    if local_csv and os.path.exists(local_csv):
        print(f"Reading {local_csv} (nrows={nrows}) ...")
        # Only request usecols that actually exist in the file's header
        header = pd.read_csv(local_csv, nrows=0).columns.tolist()
        cols = [c for c in USECOLS if c in header]
        df = pd.read_csv(local_csv, usecols=cols, nrows=nrows, low_memory=False)
        if sample_frac:
            df = df.sample(frac=sample_frac, random_state=random_state)
        print(f"Loaded {len(df):,} rows from {source} file.")
        return df, source

    print("No local file and Kaggle download unavailable -> generating a synthetic "
          "dataset with the same schema and realistic accident patterns so the "
          "pipeline can still run end-to-end.")
    n = nrows if nrows else 50000
    df = _generate_synthetic_dataset(n_samples=n, random_state=random_state)
    synthetic_path = os.path.join(DATA_DIR, "us_accidents_synthetic.csv")
    df.to_csv(synthetic_path, index=False)
    print(f"Synthetic dataset saved to {synthetic_path} ({len(df):,} rows)")
    return df, "synthetic"


if __name__ == "__main__":
    data, source = load_accidents_data(nrows=20000)
    print(f"\nData source: {source}")
    print(data.head())
    print("\nSeverity distribution:")
    print(data["Severity"].value_counts().sort_index())
