# Bank Marketing — Decision Tree Purchase Predictor

A complete, runnable project that builds a **Decision Tree Classifier** to predict
whether a customer will subscribe to a bank term deposit, using the
[UCI Bank Marketing dataset](https://archive.ics.uci.edu/dataset/222/bank+marketing)
(demographic + behavioral/campaign data).

Built for the **SkillCraft Technology** Data Science internship task.

## What this does

1. **Loads the data** — tries to auto-download the real UCI dataset on first run.
   If you're offline or the download fails, it automatically falls back to a
   synthetic dataset with the *same schema and class imbalance pattern*, so the
   whole pipeline still runs end-to-end.
2. **Cleans & encodes** demographic features (age, job, marital status, education...)
   and behavioral/campaign features (contact method, call duration, number of
   contacts, previous campaign outcome...).
3. **Trains a Decision Tree Classifier**, then runs a `GridSearchCV` hyperparameter
   search (max_depth, min_samples_split, min_samples_leaf, criterion) optimizing F1
   score (chosen over accuracy because the target classes are imbalanced).
4. **Evaluates** with accuracy, precision, recall, F1, ROC-AUC, a confusion matrix,
   and a classification report.
5. **Visualizes** the tree itself, feature importances, the ROC curve, the confusion
   matrix, and the class distribution.
6. **Saves the trained model** so you can score new customers without retraining
   (`src/predict.py`).

## Project structure

```
bank-marketing-dt/
├── data/                     # dataset lands here (auto-downloaded or synthetic)
├── models/                   # trained model saved here after running main.py
├── outputs/                  # generated plots saved here
├── src/
│   ├── data_loader.py        # download / load / synthesize dataset
│   ├── preprocessing.py      # cleaning, encoding, train/test split
│   ├── model.py               # DecisionTreeClassifier training + GridSearchCV tuning
│   ├── evaluate.py            # metrics + all plots
│   ├── main.py                 # orchestrates the full pipeline (run this)
│   └── predict.py             # score new customers with the saved model
├── requirements.txt
└── README.md
```

## How to run in VS Code

1. **Unzip** this project and open the folder in VS Code.

2. **Create a virtual environment** (recommended) and install dependencies:

   ```bash
   python -m venv venv
   # Windows:
   venv\Scripts\activate
   # macOS / Linux:
   source venv/bin/activate

   pip install -r requirements.txt
   ```

3. **Run the full pipeline:**

   ```bash
   python src/main.py
   ```

   This will:
   - Download the real UCI Bank Marketing dataset into `data/` (needs internet —
     if it can't reach UCI's servers it automatically uses a synthetic stand-in
     instead, so the script never crashes)
   - Train and tune the decision tree
   - Print accuracy / precision / recall / F1 / ROC-AUC to the terminal
   - Save plots into `outputs/`: `decision_tree.png`, `confusion_matrix.png`,
     `roc_curve.png`, `feature_importance.png`, `class_distribution.png`
   - Save the trained model to `models/decision_tree_model.joblib`

4. **Score new customers** (after step 3 has run at least once):

   ```bash
   python src/predict.py
   ```

   Edit the `sample_customers` dataframe at the bottom of `src/predict.py` to
   try your own customer profiles.

## Using the real dataset offline

If your machine has no internet access in VS Code's terminal, just manually
download `bank-full.csv` from the
[UCI page](https://archive.ics.uci.edu/dataset/222/bank+marketing) and drop it
into the `data/` folder before running `main.py` — the loader checks for a
local file first and will use it automatically.

## Notes on the dataset

The UCI Bank Marketing dataset records direct marketing phone calls from a
Portuguese bank, with the target `y` indicating whether the client subscribed
to a term deposit. Features include:

- **Demographic:** age, job, marital status, education
- **Financial:** has credit in default, average yearly balance, housing loan,
  personal loan
- **Behavioral / campaign:** contact communication type, last contact day/month,
  last contact duration, number of contacts in this campaign, days since last
  contact in a previous campaign, number of previous contacts, outcome of the
  previous campaign

`duration` (call length) is typically the strongest predictor — but note that
in a real deployment scenario it's only known *after* the call happens, so if
you want a model usable *before* calling a customer, consider dropping it and
relying on the remaining demographic/behavioral features instead. Both
versions are easy to produce: just remove `"duration"` from
`NUMERIC_COLS` in `src/preprocessing.py`.

## Customizing

- **Limit the tree depth for readability:** change `max_depth` in
  `train_decision_tree()` (`src/model.py`) or the `param_grid` used by
  `tune_decision_tree()`.
- **Try a different dataset:** as long as it has a binary target column named
  `y` plus a mix of categorical/numeric features, you can swap in your own CSV
  by placing it at `data/bank-full.csv`.
- **Swap in another model:** `RandomForestClassifier` or
  `GradientBoostingClassifier` from scikit-learn are drop-in replacements in
  `src/model.py` if you want to compare performance against the single tree.
