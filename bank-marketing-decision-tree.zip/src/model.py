"""
model.py
--------
Builds and tunes a DecisionTreeClassifier for the bank marketing
purchase-prediction task.
"""

from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import GridSearchCV


def train_decision_tree(X_train, y_train, max_depth=None, random_state=42,
                         class_weight="balanced"):
    """
    Trains a single DecisionTreeClassifier with given hyperparameters.
    class_weight='balanced' helps since the dataset is imbalanced
    (far more 'no' than 'yes' responses).
    """
    clf = DecisionTreeClassifier(
        max_depth=max_depth,
        random_state=random_state,
        class_weight=class_weight
    )
    clf.fit(X_train, y_train)
    return clf


def tune_decision_tree(X_train, y_train, random_state=42, cv=5, n_jobs=-1):
    """
    Runs a grid search over key decision tree hyperparameters to find
    the best-performing configuration via cross-validated F1 score
    (F1 is more informative than accuracy on an imbalanced target).
    """
    param_grid = {
        "max_depth": [3, 4, 5, 6, 8, 10, None],
        "min_samples_split": [2, 5, 10, 20],
        "min_samples_leaf": [1, 5, 10, 20],
        "criterion": ["gini", "entropy"],
    }

    base_clf = DecisionTreeClassifier(random_state=random_state, class_weight="balanced")

    grid_search = GridSearchCV(
        estimator=base_clf,
        param_grid=param_grid,
        scoring="f1",
        cv=cv,
        n_jobs=n_jobs,
        verbose=1
    )
    grid_search.fit(X_train, y_train)

    print(f"\nBest parameters found: {grid_search.best_params_}")
    print(f"Best cross-validated F1 score: {grid_search.best_score_:.4f}")

    return grid_search.best_estimator_, grid_search.best_params_, grid_search.best_score_
