"""
preprocessing.py
-----------------
Cleans and encodes the Bank Marketing dataset for use with a
scikit-learn DecisionTreeClassifier.
"""

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

CATEGORICAL_COLS = ["job", "marital", "education", "default", "housing",
                     "loan", "contact", "month", "poutcome"]
NUMERIC_COLS = ["age", "balance", "day", "duration", "campaign", "pdays", "previous"]
TARGET_COL = "y"


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Basic cleaning: drop duplicates, strip whitespace, handle unknowns."""
    df = df.copy()
    df = df.drop_duplicates()

    for col in df.select_dtypes(include="object").columns:
        df[col] = df[col].astype(str).str.strip()

    # 'unknown' is a valid recorded category in this dataset (not a missing value
    # we need to impute) — we keep it as its own category rather than dropping rows,
    # since dropping would discard a large fraction of the data.
    return df


def encode_features(df: pd.DataFrame):
    """
    Encodes categorical columns with LabelEncoder and returns the encoded
    dataframe plus the fitted encoders (needed later to decode feature
    importances and to encode new/incoming data consistently).
    """
    df = df.copy()
    encoders = {}

    for col in CATEGORICAL_COLS:
        if col in df.columns:
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col])
            encoders[col] = le

    target_encoder = LabelEncoder()
    df[TARGET_COL] = target_encoder.fit_transform(df[TARGET_COL])  # no=0, yes=1
    encoders[TARGET_COL] = target_encoder

    return df, encoders


def split_data(df: pd.DataFrame, test_size: float = 0.2, random_state: int = 42):
    """Splits into train/test, stratified by target to preserve class balance."""
    feature_cols = [c for c in df.columns if c != TARGET_COL]
    X = df[feature_cols]
    y = df[TARGET_COL]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )
    return X_train, X_test, y_train, y_test, feature_cols


def preprocess_pipeline(df: pd.DataFrame, test_size: float = 0.2, random_state: int = 42):
    """Runs the full cleaning -> encoding -> splitting pipeline."""
    df_clean = clean_data(df)
    df_encoded, encoders = encode_features(df_clean)
    X_train, X_test, y_train, y_test, feature_cols = split_data(
        df_encoded, test_size=test_size, random_state=random_state
    )
    return X_train, X_test, y_train, y_test, feature_cols, encoders
