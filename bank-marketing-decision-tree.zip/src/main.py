"""
main.py
-------
End-to-end pipeline: load data -> preprocess -> train decision tree
-> tune hyperparameters -> evaluate -> save plots and trained model.

Run from the project root:
    python src/main.py
"""

import os
import sys
import joblib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from data_loader import load_bank_marketing_data
from preprocessing import preprocess_pipeline
from model import train_decision_tree, tune_decision_tree
from evaluate import (
    evaluate_model, plot_confusion_matrix, plot_roc,
    plot_feature_importance, plot_decision_tree, plot_target_distribution,
    OUTPUT_DIR
)

MODEL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "models")


def main(run_grid_search: bool = True):
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs(MODEL_DIR, exist_ok=True)

    # 1. Load data
    print("Step 1: Loading dataset...")
    df, source = load_bank_marketing_data()
    print(f"Data source used: {source}")
    print(f"Dataset shape: {df.shape}")
    plot_target_distribution(df, save_path=os.path.join(OUTPUT_DIR, "class_distribution.png"))

    # 2. Preprocess
    print("\nStep 2: Preprocessing data...")
    X_train, X_test, y_train, y_test, feature_cols, encoders = preprocess_pipeline(df)
    print(f"Train size: {X_train.shape[0]} | Test size: {X_test.shape[0]}")
    print(f"Features used ({len(feature_cols)}): {feature_cols}")

    # 3. Train baseline model
    print("\nStep 3: Training baseline decision tree...")
    baseline_clf = train_decision_tree(X_train, y_train, max_depth=5)
    baseline_metrics, _, _ = evaluate_model(baseline_clf, X_test, y_test)

    # 4. Hyperparameter tuning (optional but recommended)
    best_clf = baseline_clf
    if run_grid_search:
        print("\nStep 4: Tuning hyperparameters via GridSearchCV (this may take a moment)...")
        best_clf, best_params, best_cv_score = tune_decision_tree(X_train, y_train)
    else:
        print("\nStep 4: Skipping hyperparameter tuning (run_grid_search=False).")

    # 5. Final evaluation on tuned model
    print("\nStep 5: Final evaluation (tuned model) on test set...")
    metrics, y_pred, y_proba = evaluate_model(best_clf, X_test, y_test)

    # 6. Visualizations
    print("\nStep 6: Generating visualizations...")
    plot_confusion_matrix(y_test, y_pred, save_path=os.path.join(OUTPUT_DIR, "confusion_matrix.png"))
    plot_roc(y_test, y_proba, save_path=os.path.join(OUTPUT_DIR, "roc_curve.png"))
    fi_df = plot_feature_importance(best_clf, feature_cols,
                                     save_path=os.path.join(OUTPUT_DIR, "feature_importance.png"))
    plot_decision_tree(best_clf, feature_cols,
                        save_path=os.path.join(OUTPUT_DIR, "decision_tree.png"))

    print("\nTop 5 most important features:")
    print(fi_df.head(5).to_string(index=False))

    # 7. Save the trained model + encoders for later reuse
    model_path = os.path.join(MODEL_DIR, "decision_tree_model.joblib")
    joblib.dump({"model": best_clf, "encoders": encoders, "feature_cols": feature_cols}, model_path)
    print(f"\nSaved trained model + encoders to {model_path}")

    print("\nAll done. Plots saved in the 'outputs/' folder, model saved in 'models/'.")
    return best_clf, metrics


if __name__ == "__main__":
    main(run_grid_search=True)
