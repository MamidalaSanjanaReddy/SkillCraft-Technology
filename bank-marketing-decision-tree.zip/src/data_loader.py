"""
data_loader.py
---------------
Loads the UCI Bank Marketing dataset.

Behavior:
1. If data/bank-full.csv (or bank.csv) already exists locally, use it.
2. Otherwise, try to download the official dataset directly from the
   UCI Machine Learning Repository.
3. If there is no internet access (e.g. offline machine, sandboxed
   environment), fall back to generating a realistic synthetic dataset
   with the same schema, so the rest of the pipeline always runs.

Dataset reference:
Moro, S., Cortez, P., & Rita, P. (2014). Bank Marketing [Dataset].
UCI Machine Learning Repository. https://doi.org/10.24432/C5K306
"""

import os
import io
import zipfile
import urllib.request
import numpy as np
import pandas as pd

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
UCI_ZIP_URL = "https://archive.ics.uci.edu/static/public/222/bank+marketing.zip"

RAW_COLUMNS = [
    "age", "job", "marital", "education", "default", "balance", "housing",
    "loan", "contact", "day", "month", "duration", "campaign", "pdays",
    "previous", "poutcome", "y"
]


def _download_uci_dataset(dest_dir: str) -> str | None:
    """Attempt to download and extract bank-full.csv from UCI. Returns path or None."""
    os.makedirs(dest_dir, exist_ok=True)
    try:
        print(f"Attempting to download dataset from {UCI_ZIP_URL} ...")
        with urllib.request.urlopen(UCI_ZIP_URL, timeout=20) as resp:
            raw_bytes = resp.read()
        with zipfile.ZipFile(io.BytesIO(raw_bytes)) as outer_zip:
            # The outer zip typically contains bank.zip inside it
            names = outer_zip.namelist()
            inner_zip_name = next((n for n in names if n.endswith("bank.zip")), None)
            if inner_zip_name:
                inner_bytes = outer_zip.read(inner_zip_name)
                with zipfile.ZipFile(io.BytesIO(inner_bytes)) as inner_zip:
                    target = next((n for n in inner_zip.namelist() if n.endswith("bank-full.csv")), None)
                    if target is None:
                        target = next((n for n in inner_zip.namelist() if n.endswith(".csv")), None)
                    if target:
                        inner_zip.extract(target, dest_dir)
                        extracted_path = os.path.join(dest_dir, target)
                        final_path = os.path.join(dest_dir, "bank-full.csv")
                        if extracted_path != final_path:
                            os.replace(extracted_path, final_path)
                        print(f"Downloaded and extracted dataset to {final_path}")
                        return final_path
            else:
                # Some mirrors expose the CSV directly in the outer zip
                target = next((n for n in names if n.endswith("bank-full.csv")), None)
                if target:
                    outer_zip.extract(target, dest_dir)
                    extracted_path = os.path.join(dest_dir, target)
                    final_path = os.path.join(dest_dir, "bank-full.csv")
                    if extracted_path != final_path:
                        os.replace(extracted_path, final_path)
                    return final_path
    except Exception as e:
        print(f"Download failed ({e}). Will fall back to synthetic data.")
        return None
    return None


def _generate_synthetic_dataset(n_samples: int = 4521, random_state: int = 42) -> pd.DataFrame:
    """
    Generates a realistic synthetic dataset that mirrors the schema and
    rough statistical relationships of the UCI Bank Marketing dataset.
    Used only as an offline fallback so the project runs end-to-end
    even without internet access.
    """
    rng = np.random.RandomState(random_state)

    jobs = ["admin.", "blue-collar", "entrepreneur", "housemaid", "management",
            "retired", "self-employed", "services", "student", "technician",
            "unemployed", "unknown"]
    maritals = ["married", "single", "divorced"]
    educations = ["primary", "secondary", "tertiary", "unknown"]
    contacts = ["cellular", "telephone", "unknown"]
    months = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]
    poutcomes = ["failure", "nonexistent", "success", "unknown"]

    age = rng.randint(18, 90, n_samples)
    job = rng.choice(jobs, n_samples, p=[0.12, 0.22, 0.04, 0.03, 0.13, 0.05, 0.04,
                                          0.10, 0.02, 0.17, 0.03, 0.05])
    marital = rng.choice(maritals, n_samples, p=[0.6, 0.28, 0.12])
    education = rng.choice(educations, n_samples, p=[0.15, 0.5, 0.30, 0.05])
    default = rng.choice(["yes", "no"], n_samples, p=[0.02, 0.98])
    balance = rng.normal(1300, 3000, n_samples).astype(int)
    housing = rng.choice(["yes", "no"], n_samples, p=[0.56, 0.44])
    loan = rng.choice(["yes", "no"], n_samples, p=[0.16, 0.84])
    contact = rng.choice(contacts, n_samples, p=[0.65, 0.07, 0.28])
    day = rng.randint(1, 29, n_samples)
    month = rng.choice(months, n_samples)
    duration = np.clip(rng.exponential(220, n_samples), 0, 4000).astype(int)
    campaign = rng.poisson(2.5, n_samples) + 1
    pdays = rng.choice([-1] * 800 + list(rng.randint(1, 400, 200)), n_samples)
    previous = rng.poisson(0.5, n_samples)
    poutcome = rng.choice(poutcomes, n_samples, p=[0.11, 0.0, 0.04, 0.85])

    # Build a latent "propensity to subscribe" score correlated with realistic factors,
    # then sample the target from it (mirrors known patterns in the real dataset:
    # longer call duration, prior success, student/retired status increase conversion).
    score = (
        0.0025 * duration
        + 0.6 * (poutcome == "success")
        + 0.25 * (job == "student")
        + 0.2 * (job == "retired")
        + 0.15 * (education == "tertiary")
        - 0.15 * (housing == "yes")
        - 0.2 * (loan == "yes")
        - 0.05 * campaign
        + 0.1 * (contact == "cellular")
        + rng.normal(0, 0.6, n_samples)
    )
    prob = 1 / (1 + np.exp(-(score - 1.5)))
    y = (rng.uniform(0, 1, n_samples) < prob).astype(int)
    y = np.where(y == 1, "yes", "no")

    df = pd.DataFrame({
        "age": age, "job": job, "marital": marital, "education": education,
        "default": default, "balance": balance, "housing": housing, "loan": loan,
        "contact": contact, "day": day, "month": month, "duration": duration,
        "campaign": campaign, "pdays": pdays, "previous": previous,
        "poutcome": poutcome, "y": y
    })
    return df


def load_bank_marketing_data(prefer_full: bool = True) -> tuple[pd.DataFrame, str]:
    """
    Loads the Bank Marketing dataset.

    Returns
    -------
    df : pd.DataFrame
        The loaded dataset with columns matching RAW_COLUMNS.
    source : str
        One of "local", "downloaded", or "synthetic" — describes data origin.
    """
    os.makedirs(DATA_DIR, exist_ok=True)

    candidates = ["bank-full.csv", "bank.csv"] if prefer_full else ["bank.csv", "bank-full.csv"]
    for fname in candidates:
        fpath = os.path.join(DATA_DIR, fname)
        if os.path.exists(fpath):
            df = pd.read_csv(fpath, sep=";")
            df.columns = [c.strip() for c in df.columns]
            print(f"Loaded local dataset: {fpath}  ({len(df)} rows)")
            return df, "local"

    downloaded_path = _download_uci_dataset(DATA_DIR)
    if downloaded_path and os.path.exists(downloaded_path):
        df = pd.read_csv(downloaded_path, sep=";")
        df.columns = [c.strip() for c in df.columns]
        print(f"Using downloaded dataset ({len(df)} rows)")
        return df, "downloaded"

    print("No local file and download unavailable -> generating synthetic dataset "
          "with the same schema so the pipeline can still run end-to-end.")
    df = _generate_synthetic_dataset()
    synthetic_path = os.path.join(DATA_DIR, "bank_synthetic.csv")
    df.to_csv(synthetic_path, index=False)
    print(f"Synthetic dataset saved to {synthetic_path} ({len(df)} rows)")
    return df, "synthetic"


if __name__ == "__main__":
    data, source = load_bank_marketing_data()
    print(f"\nData source: {source}")
    print(data.head())
    print(data["y"].value_counts())
