"""
predict.py
----------
Loads the saved trained model and scores new customer records.

Run from the project root:
    python src/predict.py
"""

import os
import sys
import joblib
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

MODEL_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "models", "decision_tree_model.joblib"
)


def load_artifacts(model_path: str = MODEL_PATH):
    artifacts = joblib.load(model_path)
    return artifacts["model"], artifacts["encoders"], artifacts["feature_cols"]


def encode_new_data(df_new: pd.DataFrame, encoders: dict, feature_cols: list) -> pd.DataFrame:
    """Encodes a new raw dataframe using the same encoders fit during training."""
    df_new = df_new.copy()
    for col, encoder in encoders.items():
        if col == "y" or col not in df_new.columns:
            continue
        # Map unseen categories to the encoder's "unknown" bucket if present,
        # otherwise fall back to the first known class to avoid crashing.
        known_classes = set(encoder.classes_)
        fallback = "unknown" if "unknown" in known_classes else encoder.classes_[0]
        df_new[col] = df_new[col].apply(lambda v: v if v in known_classes else fallback)
        df_new[col] = encoder.transform(df_new[col])
    return df_new[feature_cols]


def predict_customers(df_new: pd.DataFrame):
    """Takes a raw dataframe of new customers (same schema as training data,
    minus the 'y' column) and returns predictions + probabilities."""
    model, encoders, feature_cols = load_artifacts()
    X_new = encode_new_data(df_new, encoders, feature_cols)
    preds = model.predict(X_new)
    probas = model.predict_proba(X_new)[:, 1]
    y_encoder = encoders["y"]
    pred_labels = y_encoder.inverse_transform(preds)

    result = df_new.copy()
    result["predicted_y"] = pred_labels
    result["purchase_probability"] = probas
    return result


if __name__ == "__main__":
    # Example: a couple of hypothetical new customers
    sample_customers = pd.DataFrame([
        {
            "age": 35, "job": "management", "marital": "married", "education": "tertiary",
            "default": "no", "balance": 1500, "housing": "yes", "loan": "no",
            "contact": "cellular", "day": 15, "month": "may", "duration": 300,
            "campaign": 2, "pdays": -1, "previous": 0, "poutcome": "unknown"
        },
        {
            "age": 60, "job": "retired", "marital": "divorced", "education": "secondary",
            "default": "no", "balance": 8000, "housing": "no", "loan": "no",
            "contact": "cellular", "day": 5, "month": "mar", "duration": 650,
            "campaign": 1, "pdays": 90, "previous": 2, "poutcome": "success"
        },
    ])

    if not os.path.exists(MODEL_PATH):
        print(f"No trained model found at {MODEL_PATH}.\nRun `python src/main.py` first to train and save the model.")
    else:
        results = predict_customers(sample_customers)
        pd.set_option("display.max_columns", None)
        pd.set_option("display.width", 150)
        print(results[["age", "job", "duration", "poutcome", "predicted_y", "purchase_probability"]])
