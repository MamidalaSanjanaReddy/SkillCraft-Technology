"""
evaluate.py
-----------
Evaluation utilities: metrics, confusion matrix, ROC curve, feature
importance plot, and a rendering of the decision tree itself.
"""

import os
import matplotlib
matplotlib.use("Agg")  # safe for headless / script execution
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, roc_curve, roc_auc_score
)
from sklearn.tree import plot_tree

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs")


def evaluate_model(clf, X_test, y_test, label_names=("no", "yes")):
    """Computes and prints standard classification metrics."""
    y_pred = clf.predict(X_test)
    y_proba = clf.predict_proba(X_test)[:, 1]

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred)
    rec = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_proba)

    print("\n" + "=" * 50)
    print("MODEL EVALUATION RESULTS")
    print("=" * 50)
    print(f"Accuracy : {acc:.4f}")
    print(f"Precision: {prec:.4f}")
    print(f"Recall   : {rec:.4f}")
    print(f"F1 Score : {f1:.4f}")
    print(f"ROC AUC  : {auc:.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=label_names))

    metrics = {
        "accuracy": acc, "precision": prec, "recall": rec,
        "f1": f1, "roc_auc": auc
    }
    return metrics, y_pred, y_proba


def plot_confusion_matrix(y_test, y_pred, label_names=("no", "yes"), save_path=None):
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=label_names, yticklabels=label_names)
    plt.xlabel("Predicted Label")
    plt.ylabel("True Label")
    plt.title("Confusion Matrix")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150)
        print(f"Saved confusion matrix to {save_path}")
    plt.close()


def plot_roc(y_test, y_proba, save_path=None):
    fpr, tpr, _ = roc_curve(y_test, y_proba)
    auc = roc_auc_score(y_test, y_proba)

    plt.figure(figsize=(6, 5))
    plt.plot(fpr, tpr, label=f"Decision Tree (AUC = {auc:.3f})", linewidth=2)
    plt.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Random Guess")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curve")
    plt.legend(loc="lower right")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150)
        print(f"Saved ROC curve to {save_path}")
    plt.close()


def plot_feature_importance(clf, feature_names, top_n=15, save_path=None):
    importances = clf.feature_importances_
    fi_df = pd.DataFrame({"feature": feature_names, "importance": importances})
    fi_df = fi_df.sort_values("importance", ascending=False).head(top_n)

    plt.figure(figsize=(8, 6))
    sns.barplot(data=fi_df, x="importance", y="feature", color="#4C72B0")
    plt.title("Feature Importance (Decision Tree)")
    plt.xlabel("Importance")
    plt.ylabel("Feature")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150)
        print(f"Saved feature importance plot to {save_path}")
    plt.close()
    return fi_df


def plot_decision_tree(clf, feature_names, class_names=("no", "yes"),
                        max_depth_display=3, save_path=None):
    """
    Renders the trained tree. If the full tree is very deep, only the
    top `max_depth_display` levels are shown for readability; the full
    tree is still used for predictions regardless of this setting.
    """
    plt.figure(figsize=(20, 10))
    plot_tree(
        clf,
        feature_names=feature_names,
        class_names=class_names,
        filled=True,
        rounded=True,
        max_depth=max_depth_display,
        fontsize=9
    )
    plt.title(f"Decision Tree (showing top {max_depth_display} levels)")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150)
        print(f"Saved decision tree visualization to {save_path}")
    plt.close()


def plot_target_distribution(df, target_col="y", save_path=None):
    plt.figure(figsize=(5, 4))
    sns.countplot(data=df, x=target_col, palette=["#C44E52", "#55A868"])
    plt.title("Target Class Distribution")
    plt.xlabel("Subscribed (y)")
    plt.ylabel("Count")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150)
        print(f"Saved class distribution plot to {save_path}")
    plt.close()
