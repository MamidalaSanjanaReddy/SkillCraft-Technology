"""
World Bank Population Distribution Visualizer
=============================================
Generates bar charts and histograms from World Bank population data.
Run: python src/visualize.py
"""

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
import os

# ── Output directory ──────────────────────────────────────────────────────────
OUTPUT_DIR = "charts"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ── Palette ───────────────────────────────────────────────────────────────────
COLORS = {
    "primary":   "#2563EB",
    "accent":    "#F59E0B",
    "highlight": "#EF4444",
    "muted":     "#94A3B8",
    "bg":        "#F8FAFC",
    "grid":      "#E2E8F0",
}
REGION_PALETTE = [
    "#2563EB", "#10B981", "#F59E0B", "#EF4444",
    "#8B5CF6", "#EC4899", "#06B6D4", "#84CC16",
]

plt.rcParams.update({
    "font.family":      "DejaVu Sans",
    "axes.spines.top":  False,
    "axes.spines.right": False,
    "figure.facecolor": COLORS["bg"],
    "axes.facecolor":   COLORS["bg"],
    "axes.grid":        True,
    "grid.color":       COLORS["grid"],
    "grid.linewidth":   0.8,
})


# ─────────────────────────────────────────────────────────────────────────────
# 1. Load data
# ─────────────────────────────────────────────────────────────────────────────
def load_data(path: str = "data/population_data.csv") -> pd.DataFrame:
    df = pd.read_csv(path)
    year_cols = [c for c in df.columns if c.isdigit()]
    df[year_cols] = df[year_cols].apply(pd.to_numeric, errors="coerce")
    return df, year_cols


# ─────────────────────────────────────────────────────────────────────────────
# 2. Chart 1 — Top-N Countries Bar Chart (2022)
# ─────────────────────────────────────────────────────────────────────────────
def chart_top_countries(df: pd.DataFrame, n: int = 20, year: str = "2022") -> None:
    top = df.nlargest(n, year)[["Country Name", year]].copy()
    top[year] = top[year] / 1e9  # billions

    fig, ax = plt.subplots(figsize=(14, 7))
    bars = ax.barh(
        top["Country Name"][::-1], top[year][::-1],
        color=COLORS["primary"], edgecolor="white", linewidth=0.5
    )

    # Highlight top 3
    for i, bar in enumerate(bars):
        if i >= len(bars) - 3:
            bar.set_color(COLORS["accent"])

    # Value labels
    for bar, val in zip(bars, top[year][::-1]):
        ax.text(
            bar.get_width() + 0.005, bar.get_y() + bar.get_height() / 2,
            f"{val:.3f}B", va="center", fontsize=8.5, color="#334155"
        )

    ax.set_xlabel("Population (Billions)", fontsize=11, labelpad=8)
    ax.set_title(
        f"Top {n} Most Populous Countries — {year}",
        fontsize=15, fontweight="bold", pad=16, color="#1E293B"
    )
    ax.set_xlim(0, top[year].max() * 1.18)
    fig.tight_layout()
    out = f"{OUTPUT_DIR}/chart1_top{n}_countries_{year}.png"
    fig.savefig(out, dpi=150, bbox_inches="tight")
    print(f"  ✓  Saved: {out}")
    plt.close()


# ─────────────────────────────────────────────────────────────────────────────
# 3. Chart 2 — Population Distribution Histogram (2022)
# ─────────────────────────────────────────────────────────────────────────────
def chart_histogram(df: pd.DataFrame, year: str = "2022") -> None:
    pop = df[year].dropna() / 1e6  # millions

    fig, ax = plt.subplots(figsize=(12, 6))
    n_bins = 15
    counts, edges, patches = ax.hist(
        pop, bins=n_bins, color=COLORS["primary"],
        edgecolor="white", linewidth=0.8, alpha=0.9
    )

    # Colour ramp: darker = more countries
    max_count = counts.max()
    for patch, count in zip(patches, counts):
        patch.set_facecolor(
            plt.cm.Blues(0.35 + 0.55 * (count / max_count))  # type: ignore[attr-defined]
        )

    # Median & mean lines
    median = pop.median()
    mean   = pop.mean()
    ax.axvline(median, color=COLORS["accent"],    linestyle="--", linewidth=1.8, label=f"Median  {median:.1f}M")
    ax.axvline(mean,   color=COLORS["highlight"], linestyle=":",  linewidth=1.8, label=f"Mean    {mean:.1f}M")
    ax.legend(fontsize=10)

    ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:,.0f}M"))
    ax.set_xlabel("Population (Millions)", fontsize=11, labelpad=8)
    ax.set_ylabel("Number of Countries",   fontsize=11, labelpad=8)
    ax.set_title(
        f"Distribution of Country Populations — {year}",
        fontsize=15, fontweight="bold", pad=16, color="#1E293B"
    )
    fig.tight_layout()
    out = f"{OUTPUT_DIR}/chart2_population_histogram_{year}.png"
    fig.savefig(out, dpi=150, bbox_inches="tight")
    print(f"  ✓  Saved: {out}")
    plt.close()


# ─────────────────────────────────────────────────────────────────────────────
# 4. Chart 3 — Population Size Categories (Bar Chart)
# ─────────────────────────────────────────────────────────────────────────────
def chart_size_categories(df: pd.DataFrame, year: str = "2022") -> None:
    bins   = [0, 10e6, 50e6, 100e6, 500e6, float("inf")]
    labels = ["< 10M", "10 – 50M", "50 – 100M", "100 – 500M", "> 500M"]
    df = df.copy()
    df["Category"] = pd.cut(df[year], bins=bins, labels=labels)
    counts = df["Category"].value_counts().reindex(labels)

    fig, ax = plt.subplots(figsize=(10, 6))
    bars = ax.bar(
        labels, counts.values,
        color=REGION_PALETTE[:5], edgecolor="white", linewidth=0.8, width=0.6
    )
    for bar, val in zip(bars, counts.values):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.3,
            str(val), ha="center", va="bottom", fontsize=11, fontweight="bold", color="#1E293B"
        )

    ax.set_xlabel("Population Range", fontsize=11, labelpad=8)
    ax.set_ylabel("Number of Countries", fontsize=11, labelpad=8)
    ax.set_title(
        f"Countries by Population Size Category — {year}",
        fontsize=15, fontweight="bold", pad=16, color="#1E293B"
    )
    ax.set_ylim(0, counts.max() * 1.18)
    fig.tight_layout()
    out = f"{OUTPUT_DIR}/chart3_size_categories_{year}.png"
    fig.savefig(out, dpi=150, bbox_inches="tight")
    print(f"  ✓  Saved: {out}")
    plt.close()


# ─────────────────────────────────────────────────────────────────────────────
# 5. Chart 4 — Population Growth Over Time (Stacked Area / Multi-line)
# ─────────────────────────────────────────────────────────────────────────────
def chart_growth_over_time(df: pd.DataFrame, year_cols: list) -> None:
    # Top 8 countries by 2022 population
    top8 = df.nlargest(8, "2022")["Country Name"].tolist()
    subset = df[df["Country Name"].isin(top8)].set_index("Country Name")

    years = [int(y) for y in year_cols]
    fig, ax = plt.subplots(figsize=(14, 7))

    for i, country in enumerate(top8):
        vals = subset.loc[country, year_cols] / 1e9
        ax.plot(years, vals, color=REGION_PALETTE[i % len(REGION_PALETTE)],
                linewidth=2.2, label=country, marker="o", markersize=4)

    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x:.1f}B"))
    ax.set_xlabel("Year", fontsize=11, labelpad=8)
    ax.set_ylabel("Population (Billions)", fontsize=11, labelpad=8)
    ax.set_title(
        "Population Growth: Top 8 Countries (1960 – 2022)",
        fontsize=15, fontweight="bold", pad=16, color="#1E293B"
    )
    ax.legend(loc="upper left", fontsize=9, framealpha=0.7)
    fig.tight_layout()
    out = f"{OUTPUT_DIR}/chart4_growth_over_time.png"
    fig.savefig(out, dpi=150, bbox_inches="tight")
    print(f"  ✓  Saved: {out}")
    plt.close()


# ─────────────────────────────────────────────────────────────────────────────
# 6. Chart 5 — Log-scale Population Histogram
# ─────────────────────────────────────────────────────────────────────────────
def chart_log_histogram(df: pd.DataFrame, year: str = "2022") -> None:
    pop = df[year].dropna()
    log_pop = np.log10(pop)

    fig, ax = plt.subplots(figsize=(12, 6))
    ax.hist(log_pop, bins=20, color=COLORS["primary"],
            edgecolor="white", linewidth=0.8, alpha=0.9)

    ticks = [6, 7, 8, 9]
    ax.set_xticks(ticks)
    ax.set_xticklabels([f"10^{t}\n({10**t/1e6:.0f}M)" for t in ticks], fontsize=9)
    ax.set_xlabel("Population (log₁₀ scale)", fontsize=11, labelpad=8)
    ax.set_ylabel("Number of Countries",       fontsize=11, labelpad=8)
    ax.set_title(
        f"Log-Scale Distribution of Country Populations — {year}",
        fontsize=15, fontweight="bold", pad=16, color="#1E293B"
    )
    fig.tight_layout()
    out = f"{OUTPUT_DIR}/chart5_log_histogram_{year}.png"
    fig.savefig(out, dpi=150, bbox_inches="tight")
    print(f"  ✓  Saved: {out}")
    plt.close()


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("\n🌍  World Bank Population Visualizer")
    print("=" * 44)
    df, year_cols = load_data()
    print(f"  Loaded {len(df)} countries × {len(year_cols)} years\n")

    chart_top_countries(df, n=20, year="2022")
    chart_histogram(df, year="2022")
    chart_size_categories(df, year="2022")
    chart_growth_over_time(df, year_cols)
    chart_log_histogram(df, year="2022")

    print(f"\n✅  All charts saved to ./{OUTPUT_DIR}/")
