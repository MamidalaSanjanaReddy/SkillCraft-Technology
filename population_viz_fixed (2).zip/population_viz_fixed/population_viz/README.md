# 🌍 World Bank Population Distribution Visualizer

Bar charts and histograms built from World Bank **SP.POP.TOTL** data.  
51 countries · years 1960 – 2022.

---

## Quick Start (VS Code)

### 1 — Install dependencies
```bash
pip install -r requirements.txt
```

### 2a — Run the Python script (saves PNGs to `charts/`)
```bash
python src/visualize.py
```

### 2b — Run the Jupyter Notebook (interactive)
```bash
jupyter notebook population_analysis.ipynb
```
Or open `population_analysis.ipynb` directly in VS Code with the **Jupyter** extension.

---

## Charts Generated

| # | File | Description |
|---|------|-------------|
| 1 | `chart1_top20_countries_2022.png` | Horizontal bar — top 20 countries by 2022 population |
| 2 | `chart2_population_histogram_2022.png` | Histogram — country population distribution (linear) |
| 3 | `chart3_size_categories_2022.png` | Bar chart — countries grouped by size category |
| 4 | `chart4_growth_over_time.png` | Line chart — population growth 1960–2022 (top 8) |
| 5 | `chart5_log_histogram_2022.png` | Histogram — log-scale population distribution |

---

## Project Structure

```
population_viz/
├── data/
│   └── population_data.csv        ← World Bank dataset (51 countries)
├── src/
│   └── visualize.py               ← Main script (run this)
├── charts/                        ← Output PNGs (auto-created)
├── population_analysis.ipynb      ← Jupyter notebook
├── requirements.txt
└── README.md
```

---

## Extending with Full World Bank Data

1. Visit https://data.worldbank.org/indicator/SP.POP.TOTL
2. Click **Download → CSV**
3. Replace `data/population_data.csv` with the downloaded file
4. Re-run — scripts auto-detect all year columns

---

## VS Code Extensions Recommended
- **Python** (ms-python.python)
- **Jupyter** (ms-toolsai.jupyter)
