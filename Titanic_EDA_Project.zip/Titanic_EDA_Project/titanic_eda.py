import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

# -----------------------------
# Load Dataset
# -----------------------------
file_name = "Titanic-Dataset.csv"

if not os.path.exists(file_name):
    print("ERROR: train.csv not found!")
    print("Download the Titanic dataset from Kaggle and place train.csv in this folder.")
    exit()

df = pd.read_csv(file_name)

print("=" * 60)
print("First 5 Rows")
print(df.head())

print("\nShape of Dataset:", df.shape)

print("\nColumns")
print(df.columns)

print("\nInformation")
print(df.info())

print("\nMissing Values")
print(df.isnull().sum())

print("\nStatistical Summary")
print(df.describe(include='all'))

# -----------------------------
# Data Cleaning
# -----------------------------

# Fill Age with median
df["Age"] = df["Age"].fillna(df["Age"].median())

# Fill Embarked with mode
df["Embarked"] = df["Embarked"].fillna(df["Embarked"].mode()[0])

# Fill Fare if needed
if df["Fare"].isnull().sum() > 0:
    df["Fare"] = df["Fare"].fillna(df["Fare"].median())

# Drop Cabin
if "Cabin" in df.columns:
    df.drop(columns=["Cabin"], inplace=True)

# Remove duplicates
df.drop_duplicates(inplace=True)

print("\nMissing Values After Cleaning")
print(df.isnull().sum())

# -----------------------------
# Create output folder
# -----------------------------
os.makedirs("output", exist_ok=True)

sns.set(style="whitegrid")

# -----------------------------
# Survival Count
# -----------------------------
plt.figure(figsize=(6,4))
sns.countplot(x="Survived", data=df)
plt.title("Survival Count")
plt.savefig("output/survival_count.png")
plt.show()

# -----------------------------
# Survival by Gender
# -----------------------------
plt.figure(figsize=(6,4))
sns.countplot(x="Sex", hue="Survived", data=df)
plt.title("Survival by Gender")
plt.savefig("output/survival_by_gender.png")
plt.show()

# -----------------------------
# Passenger Class
# -----------------------------
plt.figure(figsize=(6,4))
sns.countplot(x="Pclass", data=df)
plt.title("Passenger Class Distribution")
plt.savefig("output/passenger_class.png")
plt.show()

# -----------------------------
# Survival by Passenger Class
# -----------------------------
plt.figure(figsize=(6,4))
sns.countplot(x="Pclass", hue="Survived", data=df)
plt.title("Survival by Passenger Class")
plt.savefig("output/survival_by_class.png")
plt.show()

# -----------------------------
# Age Distribution
# -----------------------------
plt.figure(figsize=(8,5))
sns.histplot(df["Age"], bins=30, kde=True)
plt.title("Age Distribution")
plt.savefig("output/age_distribution.png")
plt.show()

# -----------------------------
# Fare Distribution
# -----------------------------
plt.figure(figsize=(8,5))
sns.histplot(df["Fare"], bins=30, kde=True)
plt.title("Fare Distribution")
plt.savefig("output/fare_distribution.png")
plt.show()

# -----------------------------
# Correlation Heatmap
# -----------------------------
numeric_df = df.select_dtypes(include=np.number)

plt.figure(figsize=(10,8))
sns.heatmap(numeric_df.corr(), annot=True, cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.savefig("output/correlation_heatmap.png")
plt.show()

# -----------------------------
# Scatter Plot
# -----------------------------
plt.figure(figsize=(8,5))
sns.scatterplot(data=df, x="Age", y="Fare", hue="Survived")
plt.title("Age vs Fare")
plt.savefig("output/age_vs_fare.png")
plt.show()

# -----------------------------
# Box Plot
# -----------------------------
plt.figure(figsize=(6,5))
sns.boxplot(x="Survived", y="Age", data=df)
plt.title("Age vs Survival")
plt.savefig("output/age_boxplot.png")
plt.show()

# -----------------------------
# Fare by Class
# -----------------------------
plt.figure(figsize=(6,5))
sns.boxplot(x="Pclass", y="Fare", data=df)
plt.title("Fare by Passenger Class")
plt.savefig("output/fare_by_class.png")
plt.show()

# -----------------------------
# Pair Plot
# -----------------------------
sns.pairplot(df[["Survived","Pclass","Age","Fare","SibSp","Parch"]])
plt.savefig("output/pairplot.png")
plt.show()

# -----------------------------
# Insights
# -----------------------------
print("\nOverall Survival Rate")
print(round(df["Survived"].mean()*100,2), "%")

print("\nSurvival by Gender")
print(df.groupby("Sex")["Survived"].mean()*100)

print("\nSurvival by Passenger Class")
print(df.groupby("Pclass")["Survived"].mean()*100)

print("\nAverage Age by Class")
print(df.groupby("Pclass")["Age"].mean())

print("\nAverage Fare by Class")
print(df.groupby("Pclass")["Fare"].mean())

print("\nEDA COMPLETED SUCCESSFULLY")
print("Graphs saved inside the output folder.")