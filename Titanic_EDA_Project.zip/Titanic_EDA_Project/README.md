# Titanic EDA
Place Kaggle train.csv in this folder and run `python titanic_eda.py`.
